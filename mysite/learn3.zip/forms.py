# coding:utf-8
from django import forms
 
class AddForm(forms.Form):
    a = forms.IntegerField(label='鸡蛋')
    b = forms.IntegerField(label='面包')
    c = forms.IntegerField(label='馒头')
